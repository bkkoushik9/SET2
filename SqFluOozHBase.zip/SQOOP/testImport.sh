#!/bin/bash

sqoop import \
--connect jdbc:mysql://localhost:3306/consumer_complaints \
--username sqoop \
--password sqoop \
--table usstates \
--mapreduce-job-name xyz  \
--target-dir /usstates/ \
--incremental lastmodified \
--check-column modified_date \
--last-value "2016-06-18 12:36:59" \
--append
