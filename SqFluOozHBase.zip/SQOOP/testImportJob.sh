sqoop job --create usstates_job -- import \
--connect jdbc:mysql://localhost:3306/consumer_complaints \
--username sqoop --password sqoop --table usstates \
--target-dir /usstates_job/ \
--incremental append --check-column id \
--last-value 0	;
